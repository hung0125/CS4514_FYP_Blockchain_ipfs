import React, {useContext, useEffect, useState} from 'react';
import CookieUtils from '../utils/CookieUtils';
import Crypto from '../utils/Crypto';
import strs from '../utils/strings.json';

const crypto = new Crypto();
const cookieUtils = new CookieUtils();

const KeyManager = () => {
    //current encryption key
    const [enKey, setEnKey] = useState('enkey' in cookieUtils.getDictFormat()? cookieUtils.getDictFormat()['enkey']:'NO KEY');
    
    //New encryption key
    const genKey = () => {
        const confirm = prompt(strs.Transactions_Confirm);
        if (confirm == strs.Transactions_Confirm_str) {
            const newkey = crypto.genKey();
            cookieUtils.setCookie('enkey', newkey)
            setEnKey(newkey);
            alert(strs.Transactions_Ok_genkey);
        }else
            alert(strs.Transactions_Err_wrongconfirm);
    }

    //customize key
    const setKeyPopup = () => {
        const key = prompt(strs.Transactions_Enter_key);
       
        if (key != null && prompt(strs.Transactions_Confirm) == strs.Transactions_Confirm_str) {
            setEnKey(key);
            cookieUtils.setCookie('enkey', key);
            alert(strs.Transactions_Ok_setkey);
        }else
            alert(strs.Transactions_Err_wrongconfirm);
    }

    //update cookie expiration time
    const updateExpiryTime = () => {
        cookieUtils.updateExpiryTime();
    }

    if (enKey == 'NO KEY') {
        const newkey = crypto.genKey();
        cookieUtils.setCookie('enkey', newkey);
        setEnKey(newkey);
    }

    useEffect(() => {
        updateExpiryTime();
    }, [])

    return (

        <div className='flex flex-col items-center'>
            <div className='flex mx-2'>
                <h1>{strs.Transactions_Cur_enkey}{enKey}</h1>
            </div>

            <div className='flex mx-2'>
            <button onClick={genKey} className='bg-[#2952e3] py-2 px-7 mx-4 rounded-full cursor-pointer hover:bg-[#2546bd]'>
                {strs.Transactions_Gen_newkey}
            </button>
            <button onClick={setKeyPopup} className='bg-[#2952e3] py-2 px-7 mx-4 rounded-full cursor-pointer hover:bg-[#2546bd]'>
                {strs.Transactions_Set_cuskey}
            </button>
            </div>

            <div>
                <div className='p-2'>{strs.Transactions_User_responsibility}<div className='font-bold'>{strs.Transactions_User_responsibility_bold}</div></div>
            </div>
        </div>
    )
}

export default KeyManager;
import React, { useState } from 'react'

const UploadPanel = () => {
    return (
        <div className='text-white'>
            
        </div>
    )
}

export default UploadPanel;
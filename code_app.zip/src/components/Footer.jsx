const Footer = () => {
    return (
        <h1>Final Year Project AY 2022-2023, Dept. of Computer Science, City University of Hong Kong | Project Title: Decentralized Blockchain Application for File Sharing with NFT | Supervisor: Prof. XUE Chun Jason</h1>
    );
}

export default Footer;
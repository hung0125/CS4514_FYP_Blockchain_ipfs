class CookieUtils{
    constructor() {}

    getDictFormat() {
        return document.cookie.split('; ').reduce((prev, current) => {
            const [name, ...value] = current.split('=');
            prev[name] = value.join('=');
            return prev;
          }, {});
    }

    keyExists(key) {
        return key in this.getDictFormat(); 
    }

    setCookie(key, value) {
        var cookieDict = this.getDictFormat();
        cookieDict[key] = value;

        var cookieStr = ''
        for (const [k, v] of Object.entries(cookieDict)) {
            if (k != '' && v != '')
                cookieStr += `${k}=${v}; `
        }
        
        cookieStr = cookieStr.slice(0, -2);

        if ('expires' in cookieDict)
            document.cookie = cookieStr;
        else
            document.cookie = cookieStr + `; max-age=${86400*365}; path=/`;

    } 

    updateExpiryTime() {
        document.cookie += `; max-age=${86400*365}; path=/`;
    }
}

export default CookieUtils;
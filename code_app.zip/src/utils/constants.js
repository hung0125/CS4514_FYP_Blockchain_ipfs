import abi from './Transactions.json';

export const contractABI = abi.abi;
export const contractAddress = '0x8C332A2955d684655C0687e663d8b559d2ec2425';
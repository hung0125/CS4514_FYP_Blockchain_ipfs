import CryptoJS from "crypto-js";
import CookieUtils from "./CookieUtils";

class Crypto {
    cookieUtils = new CookieUtils();

    constructor(){}

    /**
     * AES-256-ECB对称加密
     * @param text {string} 要加密的明文
     * @param secretKey {string} 密钥，43位随机大小写与数字
     * @returns {string} 加密后的密文，Base64格式
     */
    AES_ECB_ENCRYPT(text) {
        if (!'enkey' in this.cookieUtils.getDictFormat())
            throw new Error('Crypto error.');

        var secretKey = this.cookieUtils.getDictFormat()['enkey'];
        var keyHex = CryptoJS.enc.Base64.parse(secretKey);
        var messageHex = CryptoJS.enc.Utf8.parse(text);
        var encrypted = CryptoJS.AES.encrypt(messageHex, keyHex, {
            "mode": CryptoJS.mode.ECB,
            "padding": CryptoJS.pad.Pkcs7
        });
        return encrypted.toString();
    }
    
    /**
     * AES-256-ECB对称解密
     * @param textBase64 {string} 要解密的密文，Base64格式
     * @param secretKey {string} 密钥，43位随机大小写与数字
     * @returns {string} 解密后的明文
     */
    AES_ECB_DECRYPT(textBase64) {
        if (!'enkey' in this.cookieUtils.getDictFormat())
            throw new Error('Crypto error.');

        var secretKey = this.cookieUtils.getDictFormat()['enkey'];
        var keyHex = CryptoJS.enc.Base64.parse(secretKey);
        var decrypt = CryptoJS.AES.decrypt(textBase64, keyHex, {
            "mode": CryptoJS.mode.ECB,
            "padding": CryptoJS.pad.Pkcs7
        });
        var output;
        try{
            output = CryptoJS.enc.Utf8.stringify(decrypt)
        }catch(error){
            console.log(error);
        }

        return output;
    }

    genKey() {
        var k = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        for (var i = 0; i < 43; i++)
            k += possible.charAt(Math.floor(Math.random() * possible.length));
        
        return k;
    }

}

export default Crypto;
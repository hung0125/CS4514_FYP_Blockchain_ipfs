// const apiToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkaWQ6ZXRocjoweDVkOEQ4NThBZEUwMTZCNjE0ODVlMzRBZDZBMzQyMzJmNTQ4RDFFN2UiLCJpc3MiOiJ3ZWIzLXN0b3JhZ2UiLCJpYXQiOjE2NjA0MDgxOTc5MDYsIm5hbWUiOiJjdHVjc2Z5cCJ9.KGrSv8gGXmQ07k_E4rvQg4ZUVRS05FLcrwGCx_2JpOQ';
// const client = new Web3Storage({ token: apiToken });

const Footer = () => {

    return (
        <div className='bg-[#002B5B] h-96 text-white text-center py-36'>
            <h1>Final Year Project AY 2022-2023, Dept. of Computer Science, City University of Hong Kong | Project Title: A Blockchain-based Decentralized Web Application for Secure Peer-to-Peer File Sharing and Management | Supervisor: Prof. XUE Chun Jason</h1>
        </div>
    );
}

export default Footer;

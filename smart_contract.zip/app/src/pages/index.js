export {default as Navbar} from './components/general/Navbar';
export {default as FileManagement} from './FileManagement';
export {default as Hello} from './Hello';
export {default as FilePanel} from './components/FileManagement/FilePanel';
export {default as Footer} from './components/general/Footer';
//optional to update default path, may delete later
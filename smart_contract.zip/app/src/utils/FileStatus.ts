export const enum FileStatus {
    PRIVATE = 'private',
    EXPIRED = 'expired',
    BROKENKEY = 'Broken Private Key'
}